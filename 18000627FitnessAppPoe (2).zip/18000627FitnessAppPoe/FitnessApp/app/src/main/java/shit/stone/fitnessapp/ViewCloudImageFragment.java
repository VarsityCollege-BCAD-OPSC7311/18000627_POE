package shit.stone.fitnessapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import shit.stone.fitnessapp.Adapters.CloudPicAdapter;
import shit.stone.fitnessapp.Models.ImageModel;


public class ViewCloudImageFragment extends Fragment {

    RecyclerView cloudRecycler;
    CloudPicAdapter cloudPicAdapter;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Photos");
    private List<ImageModel> cloudPicsList;
    FirebaseAuth mAuth;
    FirebaseUser currentUser;

    private static ViewCloudImageFragment instance;

    public static ViewCloudImageFragment getInstance()
    {
        if(instance == null)
            return new ViewCloudImageFragment();

        return instance;
    }

    public ViewCloudImageFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_cloud_image, container, false);

        mAuth = FirebaseAuth.getInstance();
        DatabaseReference myRef = database.getReference("Photos").child(mAuth.getCurrentUser().getUid());
        cloudRecycler = view.findViewById(R.id.cloudImage_Recycler);
        cloudRecycler.setHasFixedSize(true);
        cloudRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
        cloudPicsList = new ArrayList<>();

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                for(DataSnapshot cloudImages : snapshot.getChildren())
                {
                    String user = mAuth.getCurrentUser().getUid();

                    ImageModel imageModel = cloudImages.getValue(ImageModel.class);

                    cloudPicsList.add(imageModel);
                }

                cloudPicAdapter = new CloudPicAdapter(getContext(),cloudPicsList);
                cloudRecycler.setAdapter(cloudPicAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}