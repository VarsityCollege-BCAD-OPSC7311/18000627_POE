package shit.stone.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CloudPics extends AppCompatActivity {

    Button storeCloudPics,viewCloudPics;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloud_pics);
        storeCloudPics = findViewById(R.id.storeCloudImages);
        viewCloudPics = findViewById(R.id.viewCloudImages);

        storeCloudPics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.load_cloudImagePlaceHolder,StoreCloudPicsFragment.getInstance());
                transaction.commitAllowingStateLoss();
            }
        });
        viewCloudPics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.load_cloudImagePlaceHolder,ViewCloudImageFragment.getInstance());
                transaction.commitAllowingStateLoss();
            }
        });
    }
}